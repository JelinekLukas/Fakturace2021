﻿namespace Fakturace20211
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnZakaznici = new System.Windows.Forms.Button();
            this.btnZbozi = new System.Windows.Forms.Button();
            this.btnFaktury = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnZakaznici
            // 
            this.btnZakaznici.Location = new System.Drawing.Point(14, 57);
            this.btnZakaznici.Name = "btnZakaznici";
            this.btnZakaznici.Size = new System.Drawing.Size(176, 106);
            this.btnZakaznici.TabIndex = 0;
            this.btnZakaznici.Text = "Zakaznici";
            this.btnZakaznici.UseVisualStyleBackColor = true;
            // 
            // btnZbozi
            // 
            this.btnZbozi.Location = new System.Drawing.Point(226, 57);
            this.btnZbozi.Name = "btnZbozi";
            this.btnZbozi.Size = new System.Drawing.Size(160, 105);
            this.btnZbozi.TabIndex = 1;
            this.btnZbozi.Text = "Zbozi";
            this.btnZbozi.UseVisualStyleBackColor = true;
            // 
            // btnFaktury
            // 
            this.btnFaktury.Location = new System.Drawing.Point(431, 57);
            this.btnFaktury.Name = "btnFaktury";
            this.btnFaktury.Size = new System.Drawing.Size(166, 104);
            this.btnFaktury.TabIndex = 2;
            this.btnFaktury.Text = "faktury";
            this.btnFaktury.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(628, 266);
            this.Controls.Add(this.btnFaktury);
            this.Controls.Add(this.btnZbozi);
            this.Controls.Add(this.btnZakaznici);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnZakaznici;
        private System.Windows.Forms.Button btnZbozi;
        private System.Windows.Forms.Button btnFaktury;
    }
}

